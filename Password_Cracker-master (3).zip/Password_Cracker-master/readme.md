# Python Password Cracker

>A CLI bruteforce tool for cracking common passwords

## Usage Instructions :

- Download the contents of The Repository as a Zip File or clone the Repository.
- Install Python in your Machine 
- Install the python packages mentioned inside the requirments.txt file by the following command in your terminal:
    ```python3
    >>> pip install -r requirements.txt #for windows
    >>> pip3 install -r requirements.txt #for macos and linux
    ``` 
- Run the cracker.py file by running <i>python cracker.py</i> or <i>python3 cracker.py</i> on it.
- Then select the type of hash you want to decode (type only the number corresponding to the action and not thw word itself)
- Then enter the actual hash you want to crack and wait for the script to try cracking it, if possible it shows the text password, if not it displays a relevant message. 

## Author Info :

- Youtube - [Tech Rack](https://www.youtube.com/TechRack)
- Twitter - [@sahana_saikat](https://twitter.com/sahana_saikat)
- Website - [Tech Rack](https://tech-rack.in)
- Facebook - [Saikat Sahana](https://www.facebook.com/saikat.sahana.75)
- Instagram - [saikat2811](https://www.instagram.com/saikat2811/)
- LinkedIn - [Saikat Sahana](https://www.linkedin.com/in/saikat-sahana-454608118)
- Github - [saikatsahana77](https://github.com/saikatsahana77)
